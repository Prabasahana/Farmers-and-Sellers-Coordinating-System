package com.example.pricesetter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class choose extends AppCompatActivity {

    CardView seller;
    CardView farmer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_choose);

        seller= findViewById(R.id.seller_click);
        farmer= findViewById(R.id.farmer_click);

        seller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(choose.this, "Please Sign Up", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), Register.class));
            }
        });

        farmer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(choose.this, "Please Sign Up farmer", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), Register2.class));

            }
        });
    }
}