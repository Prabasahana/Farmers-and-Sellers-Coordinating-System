package com.example.pricesetter;


import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class Details extends AppCompatActivity implements OnMapReadyCallback {
    public static String EXTRA_LATITUDE="com.example.pricesetter.EXTRA_LATITUDE";
    public static String EXTRA_LONGITUDE="com.example.pricesetter.EXTRA_LONGITUDE";
    public static String FARMER_ID="com.example.pricesetter.FARMER_ID";
    public static String SELLER_ID="com.example.pricesetter.SELLER_ID";


    Double user_latitude;
    Double user_longitude;
    String user_seller=null;
    String user_farmer=null;




    GoogleMap gMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_details);

        Intent intent1=getIntent();
        user_seller=intent1.getStringExtra(Register.USER_ID_SELLER);

        Intent intent2=getIntent();
        user_farmer=intent2.getStringExtra(Register2.USER_ID_FARMER);

       SupportMapFragment supportMapFragment=(SupportMapFragment)
               getSupportFragmentManager().findFragmentById(R.id.google_map);
        supportMapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        gMap=googleMap;
        Button button= (Button) findViewById(R.id.loc);
        gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng latLng) {

                MarkerOptions markerOptions=new MarkerOptions();
                markerOptions.position(latLng);
                user_latitude=latLng.latitude;
                user_longitude=latLng.longitude;
                markerOptions.title(latLng.latitude+":"+latLng.longitude);
                gMap.clear();
                gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10));
                gMap.addMarker(markerOptions);

            }


        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2(user_latitude,user_longitude);
            }
        }); 


    }

    //Button btn = (Button)findViewById(R.id.open_activity_button);

    public void openActivity2(Double lati, Double longi){
    Intent intent = new Intent(this, calculation.class);
    intent.putExtra(EXTRA_LATITUDE, lati);
    intent.putExtra(EXTRA_LONGITUDE,longi);
    intent.putExtra(FARMER_ID,user_farmer);
    intent.putExtra(SELLER_ID,user_seller);
    startActivity(intent);
}


}