package com.example.pricesetter;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;

public class calculation extends AppCompatActivity {

    Double lat2=0.0,long2=0.0;
    TextView textView1,textView2, textView3, textView4, textView5, textView6,textView7;
    Button button;
    calc member;
    DatabaseReference ref;
    String user_seller;
    String user_farmer;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_calculation);

         Intent intent=getIntent();
         Double lat1=intent.getDoubleExtra(Details.EXTRA_LATITUDE,0);
         Double long1=intent.getDoubleExtra(Details.EXTRA_LONGITUDE,0);
         user_seller=intent.getStringExtra(Details.SELLER_ID);
         user_farmer=intent.getStringExtra(Details.FARMER_ID);

         //FirebaseDatabase database=FirebaseDatabase.getInstance();
         //final DatabaseReference ref=database.getReference();
        member = new calc();

        textView1=findViewById(R.id.textView1);
        textView2=findViewById(R.id.textView2);
        textView3=findViewById(R.id.textView3);
        textView4=findViewById(R.id.textView4);
        textView5=findViewById(R.id.textView5);
        textView6=findViewById(R.id.textView6);
        textView7=findViewById(R.id.textView7);
        button=findViewById(R.id.register);


        textView1.setText("To Dambulla "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,7.866101,80.651771)));
        textView2.setText("To Meegoda "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,6.843894,80.045994)));
        textView3.setText("To Thabuttegama "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,8.165526,80.301943)));
        textView4.setText("To Keppetipola "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,6.897134,80.874293)));
        textView5.setText("To Nuwara Eliya "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,6.969044,80.772533)));
        textView6.setText("To Veyangoda "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,7.159709,80.057858)));
        textView7.setText("To Narahenpita "+String.format(Locale.US,"%2f km",distance_to(lat1,long1,6.893583,79.882487)));

   if(user_seller != null)
    {
        ref=FirebaseDatabase.getInstance().getReference().child("Seller").child(user_seller).child("Distance");
        member.setDambull(distance_to(lat1,long1,7.866101,80.651771));
        member.setMeegoda(distance_to(lat1,long1,6.843894,80.045994));
        member.setThabuttegama(distance_to(lat1,long1,8.165526,80.301943));
        member.setKeppetipola(distance_to(lat1,long1,6.897134,80.874293));
        member.setNuwara_eliya(distance_to(lat1,long1,6.969044,80.772533));
        member.setVeyangoda(distance_to(lat1,long1,7.159709,80.057858));
        member.setNarahenpita(distance_to(lat1,long1,6.893583,79.882487));
        ref.setValue(member);
        user_seller = "";

    }
   if(user_farmer != null)
   {
       ref=FirebaseDatabase.getInstance().getReference().child("Farmer").child(user_farmer).child("Distance");
       member.setDambull(distance_to(lat1,long1,7.866101,80.651771));
       member.setMeegoda(distance_to(lat1,long1,6.843894,80.045994));
       member.setThabuttegama(distance_to(lat1,long1,8.165526,80.301943));
       member.setKeppetipola(distance_to(lat1,long1,6.897134,80.874293));
       member.setNuwara_eliya(distance_to(lat1,long1,6.969044,80.772533));
       member.setVeyangoda(distance_to(lat1,long1,7.159709,80.057858));
       member.setNarahenpita(distance_to(lat1,long1,6.893583,79.882487));
       ref.setValue(member);
       user_farmer="";
   }

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), login.class));
            }
        });
    }

    private Double distance_to(Double lat1, Double long1, Double lat2, Double long2){
        Double longDiff=long1-long2;
        Double distance=Math.sin(deg2rad(lat1))
                *Math.sin(deg2rad(lat2))
                +Math.cos(deg2rad(lat1))
                *Math.cos(deg2rad(lat2))
                *Math.cos(deg2rad(longDiff));
        distance=Math.acos(distance);
        distance=rad2deg(distance);
        distance=distance*60*1.1515;
        distance=distance*1.609344;

        return distance;

    }
    private double rad2deg(double distance){
        return (distance*180.0/Math.PI);
    }
    private double deg2rad(double lat1){
        return (lat1*Math.PI/180.0);
        }


}