package com.example.pricesetter;

public class calc {
    private Double dambull;
    private Double meegoda;
    private Double thabuttegama;
    private Double keppetipola;
    private Double nuwara_eliya;
    private Double veyangoda;
    private Double narahenpita;

    public calc() {
    }

    public Double getDambull() {
        return dambull;
    }

    public void setDambull(Double dambull) {
        this.dambull = dambull;
    }

    public Double getMeegoda() {
        return meegoda;
    }

    public void setMeegoda(Double meegoda) {
        this.meegoda = meegoda;
    }

    public Double getThabuttegama() {
        return thabuttegama;
    }

    public void setThabuttegama(Double thabuttegama) {
        this.thabuttegama = thabuttegama;
    }

    public Double getKeppetipola() {
        return keppetipola;
    }

    public void setKeppetipola(Double keppetipola) {
        this.keppetipola = keppetipola;
    }

    public Double getNuwara_eliya() {
        return nuwara_eliya;
    }

    public void setNuwara_eliya(Double nuwara_eliya) {
        this.nuwara_eliya = nuwara_eliya;
    }

    public Double getVeyangoda() {
        return veyangoda;
    }

    public void setVeyangoda(Double veyangoda) {
        this.veyangoda = veyangoda;
    }

    public Double getNarahenpita() {
        return narahenpita;
    }

    public void setNarahenpita(Double narahenpita) {
        this.narahenpita = narahenpita;
    }
}
