package com.example.pricesetter;

public class finalc {

    private String result;

    public finalc() {
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
