package com.example.pricesetter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class price_list extends AppCompatActivity {

    TextView Carrot;
    TextView Beetroot;
    TextView Radish;
    TextView Leeks;
    TextView Potato;
    TextView Onion;
    TextView Cabbage;
    TextView Tomato;
    TextView Lemon;
    TextView Chilli;
    Button btn;

    String Carrot_;
    String Beetroot_;
    String Radish_;
    String Leeks_;
    String Potato_;
    String Onion_;
    String Cabbage_;
    String Tomato_;
    String Lemon_;
    String Chilli_;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_price_list);

        Carrot=findViewById(R.id.qt_carrot);
        Beetroot= findViewById(R.id.qt_beetroot);
        Radish=findViewById(R.id.qt_radish);
        Leeks=findViewById(R.id.qt_leeks);
        Potato=findViewById(R.id.qt_potato);
        Onion=findViewById(R.id.qt_onion);
        Cabbage=findViewById(R.id.qt_cabbage);
        Tomato=findViewById(R.id.qt_tomato);
        Lemon=findViewById(R.id.qt_lemon);
        Chilli=findViewById(R.id.qt_chilli);
        btn=findViewById(R.id.back_btn);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Price_list");
        //Query checkUser=reference.equalTo(user_id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {
                    Carrot_ = snapshot.child("Carrot").getValue(String.class);
                    Beetroot_ = snapshot.child("Beetroot").getValue(String.class);
                    Radish_ = snapshot.child("Radish").getValue(String.class);
                    Leeks_ = snapshot.child("Leeks").getValue(String.class);
                    Potato_ = snapshot.child("Potato").getValue(String.class);
                    Onion_ = snapshot.child("Onion").getValue(String.class);
                    Cabbage_ = snapshot.child("Cabbage").getValue(String.class);
                    Tomato_ = snapshot.child("Tomato").getValue(String.class);
                    Lemon_= snapshot.child("Lemon").getValue(String.class);
                    Chilli_= snapshot.child("Chili").getValue(String.class);
                }

                Carrot.setText(Carrot_);
                Beetroot.setText(Beetroot_);
                Radish.setText(Radish_);
                Leeks.setText(Leeks_);
                Potato.setText(Potato_);
                Onion.setText(Onion_);
                Cabbage.setText(Cabbage_);
                Tomato.setText(Tomato_);
                Lemon.setText(Lemon_);
                Chilli.setText(Chilli_);



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(price_list.this, update.class);
                startActivity(new Intent(getApplicationContext(), update.class));
            }
        });
    }
}