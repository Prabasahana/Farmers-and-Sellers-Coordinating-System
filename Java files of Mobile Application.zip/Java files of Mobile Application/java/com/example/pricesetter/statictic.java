package com.example.pricesetter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class statictic extends AppCompatActivity {

    TextView stat1;
    TextView stat2;
    TextView stat3;
    TextView stat4;
    String stat_1;
    String stat_2;
    String stat_3;
    String stat_4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_statictic);

        stat1 = findViewById(R.id.stat1);
        stat2 = findViewById(R.id.stat2);
        stat3 = findViewById(R.id.stat3);
        stat4 = findViewById(R.id.stat4);


        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Static");
        //Query checkUser=reference.equalTo(user_id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {
                    stat_1 = snapshot.child("Carrot").getValue(String.class);
                   stat_2 = snapshot.child("Beetroot").getValue(String.class);
                    stat_3 = snapshot.child("Radish").getValue(String.class);
                    stat_4 = snapshot.child("Leeks").getValue(String.class);

                }

                stat1.setText(stat_1);
               stat2.setText(stat_2);
                stat3.setText(stat_3);
                stat4.setText(stat_4);



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}