package com.example.pricesetter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class vegetable extends AppCompatActivity {
    Switch carrotSwitch;
    Switch beetrootSwitch;
    Switch potatoSwitch;
    Switch onionSwitch;
    EditText carrot;
    EditText beetroot;
    EditText potato;
    EditText onion;
    Button btn;
    String user_id;
    finalc member;
    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegetable);

        carrotSwitch = findViewById(R.id.sw_carrot);
        beetrootSwitch=findViewById(R.id.sw_beetroot);
        potatoSwitch=findViewById(R.id.sw_potato);
        onionSwitch=findViewById(R.id.sw_onion);
        carrot = findViewById(R.id.qt_carrot);
        beetroot=findViewById(R.id.qt_beetroot);
        potato=findViewById(R.id.qt_potato);
        onion=findViewById(R.id.qt_onion);
        btn= (Button) findViewById(R.id.btn_to_final);
        member=new finalc();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        assert user != null;
        user_id=user.getUid();


        ref= FirebaseDatabase.getInstance().getReference().child("results").child(user_id);
        //member.setResult(Name);
        ref.setValue(member);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(vegetable.this,final_acti.class);
                startActivity(intent);
            }
        });
    }
}