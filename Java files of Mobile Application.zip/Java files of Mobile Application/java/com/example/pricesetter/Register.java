package com.example.pricesetter;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class Register extends AppCompatActivity {

    public static String USER_ID_SELLER="com.example.pricesetter.USER_ID";

    private TextInputEditText Name;
    private TextInputEditText Email;
    private TextInputEditText Number;
    private TextInputEditText Password;
    Button reg_button;
    TextView login_txt;
    FirebaseAuth mAuth;
    DatabaseReference ref;
    Member member;
    String user_id_seller="";



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);

        Name = (TextInputEditText)findViewById(R.id.Name);
        Email =(TextInputEditText) findViewById(R.id.reg_email);
        Number = (TextInputEditText)findViewById(R.id.number);
        Password =(TextInputEditText) findViewById(R.id.psw);
        reg_button = findViewById(R.id.reg_btn);
        login_txt = findViewById(R.id.logintxt);
        member=new Member();
        mAuth = FirebaseAuth.getInstance();
        

        reg_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = Objects.requireNonNull(Email.getText()).toString().trim();
                String password = Objects.requireNonNull(Password.getText()).toString().trim();
                final String name = Objects.requireNonNull(Name.getText()).toString().trim();
                final String number= Objects.requireNonNull(Number.getText()).toString().trim();
                String emailPattern = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";



                if (TextUtils.isEmpty(email)) {
                    Email.setError("Email is required");
                }

                if (!email.matches(emailPattern)) {
                    Email.setError("Invalid email address");
                }

                if (TextUtils.isEmpty(password)) {
                    Password.setError("Create the Password");
                }

                if (password.length() < 6) {
                    Password.setError("Password Must have more than 6 characters");
                    ((EditText) findViewById(R.id.psw)).setText("");

                }

                else {

                    mAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        user_id_seller = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
                                        ref= FirebaseDatabase.getInstance().getReference().child("Seller").child(user_id_seller);
                                        member.setName(name);
                                        member.setEmail(email);
                                        member.setPhoneNumber(number);
                                        ref.setValue(member);
                                        Intent intent = new Intent(Register.this, Details.class);
                                        intent.putExtra(USER_ID_SELLER, user_id_seller);
                                        startActivity(intent);

                                    } else {
                                        Toast.makeText(Register.this, "Error! "  + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                                    }

                                }


                            });


                    ((EditText) findViewById(R.id.Name)).setText("");
                    ((EditText) findViewById(R.id.reg_email)).setText("");
                    ((EditText) findViewById(R.id.psw)).setText("");
                    ((EditText) findViewById(R.id.number)).setText("");
                    ((EditText) findViewById(R.id.Name)).setText("");

                }
            }

        });

        login_txt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), login.class));
            }
        });
    }
}