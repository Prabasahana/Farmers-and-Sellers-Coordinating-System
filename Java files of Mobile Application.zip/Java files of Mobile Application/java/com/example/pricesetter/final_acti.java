package com.example.pricesetter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class final_acti extends AppCompatActivity {

    String user_id;
    TextView textView;
    Button btn;
    String result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_final_acti);


        textView=findViewById(R.id.text1);
        btn=findViewById(R.id.back_btn);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        assert user != null;
        user_id=user.getUid();


        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("results").child(user_id);
        //Query checkUser=reference.equalTo(user_id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {
                    result = snapshot.child("result").getValue(String.class);

                }

                textView.setText(result);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
}