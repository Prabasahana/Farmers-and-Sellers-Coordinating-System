package com.example.pricesetter;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class login extends AppCompatActivity {

    public static String USER_ID="com.example.pricesetter.USER_ID";
    private TextInputEditText Email_log;
    private TextInputEditText Password_log;
    Button Login_Button;
    TextView registration;
    FirebaseAuth mAuth;
    ImageView image;
    TextView logo;
    String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        Email_log =(TextInputEditText) findViewById(R.id.email_login);
        Password_log =(TextInputEditText) findViewById(R.id.password_login);
        image=findViewById(R.id.logo_image);
        logo=findViewById(R.id.logo_name);
        mAuth = FirebaseAuth.getInstance();
        Login_Button = findViewById(R.id.login_btn);
        registration = findViewById(R.id.reg_txt);



        Login_Button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                String email = Objects.requireNonNull(Email_log.getText()).toString().trim();
                String password = Objects.requireNonNull(Password_log.getText()).toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Email_log.setError("Email is not entered");
                }
                if (TextUtils.isEmpty(password)) {
                    Password_log.setError("Password is not entered");
                }

                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent intent = new Intent(login.this, update.class);
                                    //intent.putExtra(USER_ID, user_id);
                                    Toast.makeText(login.this, "Logged Successfully", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getApplicationContext(), update.class));

                                } else {
                                    Toast.makeText(login.this, "Error! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });


        registration.setOnClickListener(new View.OnClickListener() {
            @Override
        public void onClick(View v) {
                Intent intent=new Intent(login.this,choose.class);
                Pair[] pairs=new Pair[2];
                pairs[0]=new Pair<View,String>(image,"logo_image");
                pairs[1]=new Pair<View,String>(logo,"logo_text");
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(login.this,pairs);
                    startActivity(intent,options.toBundle());
                }

            }
        });
    }

}
